<?php 
phpinfo();
?>
